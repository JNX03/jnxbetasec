"""
Core functionality for JnxBetaSec.
"""

