"""
Test package for JnxBetaSec.
"""

